package com.cybage.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Media")
public class  Media {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int mid;
	
	@Column(name="tid")
	private int tid;
	
	@Column(name="type")
	private String type;
	
	@Column(name="path")
	private String path;
	
	public int getMediaId() {
		return mid;
	}
	public void setMediaId(int mediaid) {
		this.mid = mediaid;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
		
	
}


