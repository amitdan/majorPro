package com.cybage.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cybage.model.Request;

@Repository
public interface RequestRepository extends JpaRepository<Request,Long>{
	public List<Request> findByTid(int tid);
	public List<Request> findByUid(int uniqueid);
	public Request findByTidAndUid(int tid, int uid);
}
