package com.cybage.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cybage.model.Media;
import com.cybage.service.LoginService;


@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/control")
public class Controller {
	@Autowired
	LoginService logic;
	String fPath;
	Logger log;
	@PostMapping(value="/upmedia",consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
		public ResponseEntity<Object>uploadFile(@RequestParam("file")MultipartFile file,@RequestParam("id")  String id){
			String str="Tutor"+id;

			String type=file.getContentType();
			type=type.substring(type.lastIndexOf("/")+1);//-file-
			Path currentDirectory=Paths.get("").toAbsolutePath();
			File convertFile=new File(currentDirectory.toAbsolutePath()+"\\"+str+"\\");
			if(!convertFile.exists())
				convertFile.mkdirs();
			File exactFile=new File(currentDirectory.toAbsolutePath()+"\\"+str+"\\"+file.getOriginalFilename());
			fPath=currentDirectory.toAbsolutePath()+"\\"+str+"\\"+file.getOriginalFilename();
			try(FileOutputStream fout=new FileOutputStream(exactFile);) {
				exactFile.createNewFile();
				fout.write(file.getBytes());
				
			} catch (IOException e) {
				log.debug(e.toString());
			}
			
			logic.addMedia(Integer.parseInt(id),fPath,type);
			return new ResponseEntity<>("File uploaded successfully",HttpStatus.OK);
		}
		@PostMapping(value="/getFiles")
		public List<Media> getFiles(@RequestBody int tid ){
			return logic.getMediaTutor(tid);
		}
		
	}

