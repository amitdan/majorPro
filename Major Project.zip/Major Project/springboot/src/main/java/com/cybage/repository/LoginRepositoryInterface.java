package com.cybage.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

//import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cybage.model.Info;
@Repository
public interface LoginRepositoryInterface extends JpaRepository<Info,Integer>{
		public Info findByEmail(String email);

//		public ArrayList<Info> findByRole(String roletype);

		public List<Info> findByRole(String roletype);
		public Info findByEmailAndPassword(String email, String password);

	
}
