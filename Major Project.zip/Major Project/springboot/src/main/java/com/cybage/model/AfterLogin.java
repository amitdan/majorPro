package com.cybage.model;


import java.util.List;

public class AfterLogin {
	Info info;
	List<Info> listInfo;
	List<Info> approvedData;
	
	public List<Info> getApprovedData() {
		return approvedData;
	}
	public void setApprovedData(List<Info> approvedData) {
		this.approvedData = approvedData;
	}
	public Info getInfo() {
		return info;
	}
	public void setInfo(Info info) {
		this.info = info;
	}
	public List<Info> getListInfo() {
		return listInfo;
	}
	public void setListInfo(List<Info> listInfo) {
		this.listInfo = listInfo;
	}
}
