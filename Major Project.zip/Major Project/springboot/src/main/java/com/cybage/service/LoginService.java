package com.cybage.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Arrays;
import java.util.List;

import org.apache.tomcat.util.codec.binary.Base64;
import com.cybage.model.AfterLogin;
import com.cybage.model.Info;
import com.cybage.model.Media;
import com.cybage.model.Request;
import com.cybage.repository.LoginRepositoryInterface;
import com.cybage.repository.MediaRepository;
import com.cybage.repository.RequestRepository;

@Service
public class LoginService {

	@Autowired
	private RequestRepository reqrepo;
	@Autowired
	private LoginRepositoryInterface loginrepo;

	@Autowired
	private MediaRepository mrepo;

	String tutor = "Tutor";
	Base64 base64 = new Base64();


	public AfterLogin getDetail(Info info) {

		AfterLogin al = new AfterLogin();
		List<Request> reqList;
		List<Info> infoList = new ArrayList<>();
		List<Info> appList = new ArrayList<>();


		if (loginrepo.findByEmailAndPassword(info.getEmail(),
				Arrays.toString(base64.encode(info.getPassword().getBytes()))) != null) {
			al.setInfo(loginrepo.findByEmailAndPassword(info.getEmail(),
					Arrays.toString(base64.encode(info.getPassword().getBytes()))));
			al.getInfo().setPassword("");

			if (al.getInfo().getRole().equals(tutor)) {
				reqList = reqrepo.findByTid(al.getInfo().getUniqueId());
				for (Request req : reqList) {
					if ("Pending".equals(req.getStatus())) {
						loginrepo.findOne(req.getUid()).setPassword("");
						infoList.add(loginrepo.findOne(req.getUid()));
					}
					if ("Approved".equals(req.getStatus())) {
						loginrepo.findOne(req.getUid()).setPassword("");
						appList.add(loginrepo.findOne(req.getUid()));
					}
				}
				al.setListInfo(infoList);
			}
			
			else 
			{
				infoList = loginrepo.findByRole(tutor);
				reqList = reqrepo.findByUid(al.getInfo().getUniqueId());
				for (Request req : reqList) {

					infoList.remove(loginrepo.findOne(req.getTid()));
					if ("Approved".equals(req.getStatus())) {
						appList.add(loginrepo.findOne(req.getTid()));
					}
				}
				System.out.println(infoList);
				al.setListInfo(infoList);
				al.setApprovedData(appList);
			}
			return al;
		}
		return null;

	}

	public AfterLogin add(Info s) {
		AfterLogin al = new AfterLogin();
		al.setApprovedData(null);
		if (loginrepo.findByEmail(s.getEmail()) == null) {
			s.setPassword(Arrays.toString(base64.encode(s.getPassword().getBytes())));
			loginrepo.save(s);
			al.setInfo(loginrepo.findByEmail(s.getEmail()));

			if(s.getRole().equals("User"))
				al.setListInfo(loginrepo.findByRole("Tutor"));

			al.getInfo().setPassword("");
			if (s.getRole().equals("User"))
				al.setListInfo(loginrepo.findByRole(tutor));

			else
				al.setListInfo(null);
			return al;
		}
		return null;

	}


	public void change(Request req) {

		if ("Pending".equals(req.getStatus())) {

			reqrepo.save(req);
		} else {
			reqrepo.findByTidAndUid(req.getTid(), req.getUid()).setStatus(req.getStatus());
			reqrepo.save(reqrepo.findByTidAndUid(req.getTid(), req.getUid()));
		}

	}

	public List<Info> fetchApproved(int n) {
		List<Request> req;
		req = reqrepo.findByTid(n);
		List<Info> infoList = new ArrayList<>();
		for (Request r : req)
			infoList.add(loginrepo.findOne(r.getUid()));
		return infoList;
	}

	public Info updateProf(Info i) {
		Info info = loginrepo.findOne(i.getUniqueId());
		info.setFname(i.getFname());
		info.setLname(i.getLname());
		info.setPhone(i.getPhone());
		info.setCourse(i.getCourse());
		loginrepo.save(info);
		return info;
	}

	public void addMedia(int m, String fPath, String type) {
		Media media=new Media();
		media.setTid(m);
		media.setType(type);
		media.setPath(fPath);
		mrepo.save(media);
	}

	public List<Media> getMediaUser(int u) {

		List<Media> mediaList = new ArrayList<>();
		mrepo.findByTid(u).forEach(mediaList::add);
		return mediaList;

	}
	public List<Media> getMediaTutor(int tid) {

		List<Media> mediaList = new ArrayList<>();
		mrepo.findByTid(tid).forEach(mediaList::add);
		return mediaList;
	}
}