package com.cybage.controller;


import java.util.List;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.AfterLogin;
import com.cybage.model.Info;
import com.cybage.model.Request;
import com.cybage.service.LoginService;


@RestController

@CrossOrigin(origins = "http://localhost:4200")

@RequestMapping(value="/project")
public class LoginController {
	@Autowired
	private LoginService iService;
	Logger log;
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public AfterLogin login(@RequestBody Info info) {
		return iService.getDetail(info);
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public AfterLogin addTo(@RequestBody Info s) {
		return iService.add(s);
	}
//	@RequestMapping(value = "/changeRequest", method = RequestMethod.POST)
//	public boolean changeStatus(@RequestBody Request req) {
//		
//		return iService.change(req);
//	}
	@PostMapping(value = "/changeRequest")
	public void changeStatus(@RequestBody Request req) {
		iService.change(req);
	}
	@PostMapping(value = "/approvedInfo")
	public List<Info> approvedInfo(@RequestBody int n) {
		return iService.fetchApproved(n);
	}
	@PostMapping(value = "/updateProfile")
	public Info updateProfile(@RequestBody Info i) {
		return iService.updateProf(i);

	}
}