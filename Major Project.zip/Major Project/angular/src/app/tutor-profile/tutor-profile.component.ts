import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Info } from '../shared/Info';
import { InfoService } from '../shared/InfoService';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Media } from '../shared/Media';
import { DomSanitizer } from '@angular/platform-browser';
@Component({
  selector: 'app-tutor-profile',
  templateUrl: './tutor-profile.component.html',
  styleUrls: ['./tutor-profile.component.css']
})
export class TutorProfileComponent implements OnInit {

  updateForm: FormGroup;
  submitted = false;
  tutorInfo: Info;
  userInfoList: Info[];
  approvedUsers: Info[];
  selectedFiles: FileList;
  currentFileUpload: File;
  med:Media[];
  progress: { percentage: number } = { percentage: 0 }

  constructor(private formBuilder: FormBuilder, private route: Router,
    private infoServ: InfoService,private _sanitizer: DomSanitizer) { }

  ngOnInit() {
    this.updateForm = this.formBuilder.group({
      fname: ['', [Validators.required, Validators.minLength(3)]],
      lname: ['', [Validators.required, Validators.minLength(3)]],
      phone: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      course: ['Java']
    });
    
    

    if(JSON.parse(sessionStorage.getItem("info"))==null){
      this.route.navigateByUrl("/login");
    }
    else{
    if (JSON.parse(sessionStorage.getItem("info")).role != "Tutor")
      this.route.navigateByUrl("/login");
    else{
      this.tutorInfo = JSON.parse(sessionStorage.getItem("info"));
    this.userInfoList = JSON.parse(sessionStorage.getItem("listInfo"));
    this.approvedUsers=JSON.parse(sessionStorage.getItem("approvedInfo"));

    document.getElementById('login').innerHTML = "Welcome ," + this.tutorInfo.fname;
    document.getElementById('register').innerHTML = "";
    this.med=JSON.parse(sessionStorage.getItem('media'));
    if(this.med==null)
      document.getElementById('mediaMsg').innerHTML="No Files Uploaded By You Till Now!!";
    
    this.infoServ.getMedia(this.tutorInfo.uniqueId).
        subscribe(data=>sessionStorage.setItem('media',JSON.stringify(data)));
    }
    }
  }

  deleteData(uid: number, event: any) {
    var target = event.target;
    var idAttr = target.attributes.id;
    var value = idAttr.nodeValue;

    document.getElementById("mssg").innerHTML = "You have " + value + " sucessfully";
    this.userInfoList.forEach((item, index) => {
      if (item.uniqueId === uid) {
        this.userInfoList.splice(index, 1);
        sessionStorage.setItem("listInfo", JSON.stringify(this.userInfoList));

        this.infoServ
          .changeRequest(this.tutorInfo.uniqueId, uid, value)
          .subscribe();
      }
    });
  }
  logOut() {
    this.route.navigateByUrl("/login");
    sessionStorage.clear();
    document.getElementById('login').innerHTML = '<i class="fa fa-fw fa-sign-in"></i>Login';
    document.getElementById('register').innerHTML='<i class="fa fa-fw fa-user"></i>Register';
  }
  get f() { return this.updateForm.controls; }
  onSubmit() {

    this.submitted = true;
    // stop here if form is invalid
    if (this.updateForm.invalid) {
      return;
    }
    else {
      if (this.updateForm.controls['fname'].value && this.updateForm.controls['lname'].value && this.updateForm.controls['phone'].value) {
        this.infoServ.
          updateUser(this.updateForm.value, this.tutorInfo.uniqueId)
          .subscribe(data => {
            this.tutorInfo = data;
            sessionStorage.setItem("info", JSON.stringify(this.tutorInfo));
            document.getElementById('login').innerHTML = "Welcome ," + this.tutorInfo.fname;
            document.getElementById("message1").innerHTML = "Successfully Updated your Details."
          });
        this.updateForm = this.formBuilder.group({
          fname: ['', Validators.minLength(3)],
          lname: [''],
          phone: [''],
          course: ['Java']
        });
      }
      else {
        this.updateForm = this.formBuilder.group({
          fname: ['', [Validators.required, Validators.minLength(3)]],
          lname: ['', [Validators.required, Validators.minLength(3)]],
          phone: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
          course: ['Java']
        });
        return
      }
    }
  }
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
  upload() {
    this.progress.percentage = 0;
 
    this.currentFileUpload = this.selectedFiles.item(0);
    this.infoServ.pushFileToStorage(this.currentFileUpload,this.tutorInfo.uniqueId)
    .subscribe(event => {
      if (event.type === HttpEventType.UploadProgress) {
        this.progress.percentage = Math.round(100 * event.loaded / event.total);
      } else if (event instanceof HttpResponse) {
        document.getElementById('fileUpLoad').innerHTML='File is completely uploaded!';
      }
    })
 
    this.selectedFiles = undefined;
  }
    setSrc(src:string){ 
      return this._sanitizer.bypassSecurityTrustUrl(src);
    }
}
