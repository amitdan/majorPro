import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { InfoService } from '../shared/InfoService';
import { InfoList } from '../shared/InfoList';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register-component',
  templateUrl: './register-component.component.html',
  styleUrls: ['./register-component.component.css']
})
export class RegisterComponentComponent implements OnInit {

  registerForm: FormGroup;
  submitted = false;
  infoList: InfoList;

  constructor(private formBuilder: FormBuilder,private service:InfoService,private route:Router) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
          fname: ['', [Validators.required, Validators.minLength(3)]],
          lname: ['', [Validators.required, Validators.minLength(3)]],
          email: ['', [Validators.required, Validators.email]],
          password: ['', [Validators.required, Validators.minLength(8)]],
          phone:['',[Validators.required, Validators.minLength(10),Validators.maxLength(10)]],
          role: ['', Validators.required],
          cpassword: ['', [Validators.required, Validators.minLength(8)]],
          course:['Java']
      });
      if(sessionStorage.getItem("info")){
        if(JSON.parse(sessionStorage.getItem("info")).role==="User")
          this.route.navigateByUrl("/userProfile");
        else if (JSON.parse(sessionStorage.getItem("info")).role==="Tutor")
          this.route.navigateByUrl("/tutorProfile");
      }  
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  onSubmit() {

      this.submitted = true; 
      // stop here if form is invalid
      if (this.registerForm.invalid) { 
          return;
      }
        else {
          if (this.registerForm.controls['password'].value!=this.registerForm.controls['cpassword'].value) {

            document.getElementById('message1').style.color = 'red';
            document.getElementById('message1').innerHTML = 'Passwords Not Matching';
            return;
          }
          else{
            this.service.
            regUser(this.registerForm.value)
            .subscribe(data=>{

                this.infoList=data;   
                if(this.infoList!=null){
          
                sessionStorage.setItem("info",JSON.stringify(this.infoList.info));
                sessionStorage.setItem("listInfo",JSON.stringify(this.infoList.listInfo));
          
                if(this.infoList.info.role==='Tutor')
                  this.route.navigateByUrl("/tutorProfile");
          
                else 
                  this.route.navigateByUrl("/userProfile"); 
              }
              else
                document.getElementById("errormssg").innerHTML="E-mail Id Already Registered";   
              
              });
          }
      }
  }
    showCourse(){
            document.getElementById("show").style.display="block";
    }
    hideCourse(){
            document.getElementById("show").style.display="none";
            this.registerForm.controls['course'].setValue("NA");
    } 
}
