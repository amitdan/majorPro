import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { Router } from '@angular/router';
import { InfoList } from '../shared/InfoList';
import { InfoService } from '../shared/InfoService';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  infoList:InfoList;

  constructor(private formBuilder: FormBuilder,private service:InfoService,private route:Router) { 
  }

  ngOnInit() {
      
      this.loginForm = this.formBuilder.group({
          email: ['', [Validators.required, Validators.email]],
          password: ['', [Validators.required, Validators.minLength(6)]]
      });
      if(sessionStorage.getItem("info")){
        if(JSON.parse(sessionStorage.getItem("info")).role==="User")
          this.route.navigateByUrl("/userProfile");
        else if (JSON.parse(sessionStorage.getItem("info")).role==="Tutor")
          this.route.navigateByUrl("/tutorProfile");
      }  
  }

  // convenience getter for easy access to form fields
  get f() { 
    return this.loginForm.controls; 
  }

  onSubmit() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.loginForm.invalid) {
          return;
      }
      
      
      this.service.
      login(this.loginForm.value)
      .subscribe(data=>{
        
        this.infoList=data;
        if(this.infoList!=null){
          
          sessionStorage.setItem("info",JSON.stringify(this.infoList.info));
          sessionStorage.setItem("listInfo",JSON.stringify(this.infoList.listInfo));
          sessionStorage.setItem("approvedInfo",JSON.stringify(this.infoList.approvedData));
          
          if(this.infoList.info.role==='Tutor')
            this.route.navigateByUrl("/tutorProfile");
          
          else 
            this.route.navigateByUrl("/userProfile"); 
        }
        else
          document.getElementById("errormssg").innerHTML="Invalid Credentials";   
    });
    
  }

}
