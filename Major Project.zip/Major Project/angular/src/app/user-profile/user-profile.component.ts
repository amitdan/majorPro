import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Info } from '../shared/Info';
import { InfoService } from '../shared/InfoService';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';


@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  userInfo:Info;
  tutorInfoList:Info[];
  updateForm: FormGroup;
  approvedTutors: Info[];
  submitted = false;
  constructor(private route:Router,private infoServ:InfoService,private formBuilder: FormBuilder) { }

  ngOnInit() {
    
    this.updateForm = this.formBuilder.group({
      fname: ['', [Validators.required, Validators.minLength(3)]],
      lname: ['', [Validators.required, Validators.minLength(3)]],
      phone: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]]
    });

    if(JSON.parse(sessionStorage.getItem("info")).role!="User")
      this.route.navigateByUrl("/login");

      this.userInfo=JSON.parse(sessionStorage.getItem("info"));
      this.tutorInfoList=JSON.parse(sessionStorage.getItem("listInfo"));
      this.approvedTutors=JSON.parse(sessionStorage.getItem("approvedInfo"));
      document.getElementById('login').innerHTML = "Welcome ," + JSON.parse(sessionStorage.getItem("info")).fname;
      document.getElementById('register').innerHTML = "";
  }
  logOut(){
    this.route.navigateByUrl("/login");
    sessionStorage.clear();
    document.getElementById('login').innerHTML='<i class="fa fa-fw fa-sign-in"></i>Login';
    document.getElementById('register').innerHTML='<i class="fa fa-fw fa-user"></i>Register';
  }
  follow(tid:number){
    document.getElementById("mssg").innerHTML="You have sucessfully sent the Request";
      this.tutorInfoList.forEach((item,index)=>
      {
        if(item.uniqueId===tid){
          this.tutorInfoList.splice(index,1);
          sessionStorage.setItem("listInfo",JSON.stringify(this.tutorInfoList));

          this.infoServ
          .changeRequest(tid,this.userInfo.uniqueId,"Pending")
          .subscribe();
        }
      });
  }
  get f() { return this.updateForm.controls; }
  onSubmit() {

    this.submitted = true;
    // stop here if form is invalid
    if (this.updateForm.invalid) {
      return;
    }
    else {
      if (this.updateForm.controls['fname'].value && this.updateForm.controls['lname'].value && this.updateForm.controls['phone'].value) {
        this.infoServ.
          updateUser(this.updateForm.value, this.userInfo.uniqueId)
          .subscribe(data => {
            this.userInfo = data;
            sessionStorage.setItem("info", JSON.stringify(this.userInfo));
            document.getElementById('login').innerHTML = "Welcome ," + this.userInfo.fname;
            document.getElementById("message1").innerHTML = "Successfully Updated your Details."
          });
        this.updateForm = this.formBuilder.group({
          fname: ['', Validators.minLength(3)],
          lname: [''],
          phone: ['']
        });
      }
      else {
        this.updateForm = this.formBuilder.group({
          fname: ['', [Validators.required, Validators.minLength(3)]],
          lname: ['', [Validators.required, Validators.minLength(3)]],
          phone: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]]
        });
        return
      }
    }
  }

}
