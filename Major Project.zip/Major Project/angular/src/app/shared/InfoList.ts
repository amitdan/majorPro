import { Info } from './Info';

export class InfoList{
    info:Info;
    listInfo:Info[];
    approvedData:Info[];
}