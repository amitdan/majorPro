export class Request{
    rid:number;
    tid:number;
    uid:number;
    status:string;
    constructor(tid:number,uid:number,status:string){
        this.tid=tid;
        this.uid=uid;
        this.status=status;
        }
}