import {Injectable} from '@angular/core'
import { HttpClient, HttpEvent, HttpRequest} from '@angular/common/http';
import { Info } from './Info';
import { InfoList } from './InfoList';
import {Request} from './Request';
import { Observable } from 'rxjs';
import { Media } from './Media';

@Injectable({
    providedIn:'root'
})
export class InfoService{
  
    constructor(private http:HttpClient){}
    
    regUser(info:Info){
        return this.http.post<InfoList>('http://localhost:8080/project/register',info);
    }
    login(info:Info){
        return this.http.post<InfoList>('http://localhost:8080/project/login',info);
    }
    updateUser(info:Info,id:number){
        info.uniqueId=id;
        return this.http.post<Info>('http://localhost:8080/project/updateProfile',info);
    }
    req:Request;
    changeRequest(tid:number,uid:number,status:string){
        
        this.req=new Request(tid,uid,status);
        return this.http.post('http://localhost:8080/project/changeRequest',this.req);
        
    }
    pushFileToStorage(file: File ,id:number): Observable<HttpEvent<{}>> {
        let formdata: FormData = new FormData();

        formdata.append('id',JSON.stringify(id));
        formdata.append('file', file);
        
        const req = new HttpRequest('POST', 'http://localhost:8080/control/upmedia',(formdata), {
          reportProgress: true,
          responseType: 'text'
        });
     
        return this.http.request(req);
      }
      
      getMedia(uniqueId: number) {
        return this.http.post<Media[]>('http://localhost:8080/control/getFiles',uniqueId);
      }
      searchTutor(course:string){
        return this.http.post<Info[]>('http://localhost:8080/project/search',course);
      }
      
}