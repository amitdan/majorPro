
export class Info{
    uniqueId:number;
    fname:string;
    lname:string;
    role:string;
    email:string;
    password:string;
    course:string;
    phone:string;
    likes:number;
    constructor(email:string,password:string){
        this.email=email;
        this.password=password;
    }

}