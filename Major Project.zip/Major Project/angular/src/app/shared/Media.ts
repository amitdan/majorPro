export class Media{
    path:string;
    type:string;
    tid:number;
}