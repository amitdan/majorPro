import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponentComponent } from './login-component/login-component.component';
import { RegisterComponentComponent } from './register-component/register-component.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { TutorProfileComponent } from './tutor-profile/tutor-profile.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:"login",component:LoginComponentComponent},
  {path:"register",component:RegisterComponentComponent},
  {path:"userProfile",component:UserProfileComponent},
  {path:"tutorProfile",component:TutorProfileComponent},
  {path:"home",component:HomeComponent},
  { path: '',   redirectTo: '/home', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{anchorScrolling:'enabled'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
